import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import {
  Leaf,
  Heart,
  Users,
  MapPin,
  Phone,
  Mail,
  Star,
  Sprout,
  Cookie,
  Stethoscope,
  Building,
  Menu,
  X,
  Facebook,
  Instagram,
  Twitter,
  Youtube,

} from 'lucide-react';
import './App.css';
import NPIPBiosecurity from './components/NPIPBiosecurity.jsx';
import FarmersMarket from './components/FarmersMarket.jsx';

// Import images
import organicFarmingImg from './assets/organic-farming.jpg';
import beekeepingImg from './assets/beekeeping.jpg';
import cottageBakingImg from './assets/cottage-baking.jpg';

// Import animal images
import allyCatImg from './assets/allycat-sleeping.jpeg';
import yardieTabbyImg from './assets/yardie-tabby.jpeg';
import bobYardieImg from './assets/bob-yardie-cats.jpeg';
import lyannaMormontImg from './assets/lyanna-mormont.jpeg';
import brandonStarkImg from './assets/brandon-stark.jpeg';

import farmLogo from './assets/nevaeh-seniah-logo.png';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const services = [
    {
      icon: <Sprout className="w-8 h-8 organic-text" />,
      title: "Organic Farming",
      description: "Sustainable agriculture practices with certified organic produce, heritage livestock, and soil health focus.",
      image: organicFarmingImg,
      features: ["Ayam Cemani Chickens", "Pasture-fed Rooster Roulettes", "Seasonal Organic Produce", "Sustainable Practices"]
    },
    {
      icon: <Leaf className="w-8 h-8 honey-text" />,
      title: "Certified Beekeeping",
      description: "Professional beekeeping services, pollinator education, and raw honey production with environmental stewardship.",
      image: beekeepingImg,
      features: ["Hive Management", "Pollinator Education", "Raw Honey Products", "Environmental Conservation"]
    },
    {
      icon: <Cookie className="w-8 h-8 earth-text" />,
      title: "Cottage Food Bakery",
      description: "Licensed cottage food production featuring gluten-free options and clean-label baked goods with healthy twists.",
      image: cottageBakingImg,
      features: ["Gluten-Free Options", "Clean-Label Ingredients", "Time-Honored Recipes", "Custom Orders"]
    },
    {
      icon: <Heart className="w-8 h-8 star-wars-accent" />,
      title: "Health & Wellness",
      description: "Personal transformation advocacy through intermittent fasting, clean eating, and mindful living practices.",
      image: null,
      features: ["45+ Pound Weight Loss Journey", "Intermittent Fasting", "Clean Eating Education", "Wellness Workshops"]
    }
  ];

  return (
    <Router>
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-border z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-2">
                <Link to="/" className="flex items-center space-x-2">
                  <img src={farmLogo} alt="Nevaeh Seniah Logo" className="w-10 h-10" />
                  <span className="text-xl font-bold organic-text">Nevaeh Seniah</span>
                </Link>
              </div>
              
              {/* Desktop Navigation */}
              <div className="hidden md:flex space-x-8">
                <Link to="/" className="capitalize transition-colors text-muted-foreground hover:text-primary">home</Link>
                <Link to="/#about" className="capitalize transition-colors text-muted-foreground hover:text-primary">about</Link>
                <Link to="/#services" className="capitalize transition-colors text-muted-foreground hover:text-primary">services</Link>
                <Link to="/#farm" className="capitalize transition-colors text-muted-foreground hover:text-primary">farm</Link>
                <Link to="/npip-biosecurity" className="capitalize transition-colors text-muted-foreground hover:text-primary">NPIP & Biosecurity</Link>
                <Link to="/farmers-market" className="capitalize transition-colors text-muted-foreground hover:text-primary">Farmer's Market</Link>
                <Link to="/#contact" className="capitalize transition-colors text-muted-foreground hover:text-primary">contact</Link>
              </div>

              {/* Mobile Menu Button */}
              <button
                className="md:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

            {/* Mobile Navigation */}
            {isMenuOpen && (
              <div className="md:hidden py-4 border-t border-border">
                <Link to="/" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>home</Link>
                <Link to="/#about" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>about</Link>
                <Link to="/#services" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>services</Link>
                <Link to="/#farm" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>farm</Link>
                <Link to="/npip-biosecurity" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>NPIP & Biosecurity</Link>
                <Link to="/farmers-market" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>Farmer's Market</Link>
                <Link to="/#contact" className="block w-full text-left py-2 capitalize text-muted-foreground hover:text-primary" onClick={() => setIsMenuOpen(false)}>contact</Link>
              </div>
            )}
          </div>
        </nav>

        <Routes>
          <Route path="/npip-biosecurity" element={<NPIPBiosecurity />} />
          <Route path="/farmers-market" element={<FarmersMarket />} />          <Route path="/" element={
            <>
              {/* Hero Section */}
              <section id="home" className="relative min-h-screen flex items-center justify-center hero-gradient">
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
                  <h1 className="text-5xl md:text-7xl font-bold mb-6 fade-in">
                    Where the Force Meets the Farm
                  </h1>
                  <p className="text-xl md:text-2xl mb-8 fade-in" style={{animationDelay: '0.2s'}}>
                    Organic farming, certified beekeeping, and wellness advocacy in LaGrange, Georgia
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center fade-in" style={{animationDelay: '0.4s'}}>
                    <Button 
                      size="lg" 
                      className="bg-white text-primary hover:bg-white/90 pulse-glow"
                      onClick={() => scrollToSection('farm')}
                    >
                      Explore Our Farm
                    </Button>
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="border-white text-white hover:bg-white hover:text-primary"
                      onClick={() => scrollToSection('services')}
                    >
                      Our Services
                    </Button>
                  </div>
                </div>
              </section>

              {/* About Section */}
              <section id="about" className="py-20 bg-muted/30">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="grid md:grid-cols-2 gap-12 items-center">
                    <div className="slide-in-left">
                      <h2 className="text-4xl font-bold mb-6 organic-text">Meet Tara - The Quirky Farm Girl</h2>
                      <p className="text-lg text-muted-foreground mb-6">
                        I believe the best things take time—just like good compost, slow sunrises, and a well-seasoned cast iron skillet. At Nevaeh Seniah, LLC, my all-organic farm in LaGrange, Georgia, we grow with intention and work with nature, not against it.
                      </p>
                      <p className="text-lg text-muted-foreground mb-6">
                        Here, we nurture an organic heirloom garden with a variety of fruits, vegetables and herbs. Specialize breeding of the rare Java, Indonesia Ayam Cemani chickens which are pasture raised, organically fed, and roam free spirited with the Rooster Roulettes. Our hardworking honeybees aka Jedi Knights provide pollination throughout the farm and golden wildflower honey. Add in the dynamic duo of Leia and Han Solo the magnificent miniature donkeys and we have an entertaining farm.
                      </p>
                      <p className="text-lg text-muted-foreground mb-6">
                        After personally losing over 45 pounds through intermittent fasting, organic choices and whole-food eating, I am passionate about sharing how real food—from seed to plate—can heal and nourish. I believe in transparency, sustainability, and doing things the right way, even when it is not the fast way. Because around here, we grow more than food—we grow community.
                      </p>
                      <div className="flex flex-wrap gap-2 mb-6">
                        <Badge variant="secondary">Certified Beekeeper</Badge>
                        <Badge variant="secondary">Cottage Food Licensed</Badge>
                        <Badge variant="secondary">Health Advocate</Badge>
                        <Badge variant="secondary">Small Business Owner</Badge>
                      </div>
                    </div>
                    <div className="slide-in-right">
                      <Card className="farm-card">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Star className="w-5 h-5 star-wars-accent" />
                            Star Wars Themed Farm
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground mb-4">
                            Meet our beloved miniature donkeys, Leia (black) and Han Solo (white), who serve as 
                            the charming ambassadors of our Star Wars-themed farm. They embody the spirit of 
                            adventure and resilience that drives our sustainable farming mission.
                          </p>
                          <div className="text-sm text-muted-foreground">
                            "You will often find me sharing my journey (with some humor) through social media 
                            as I work to inspire others to reconnect with their food, their health, and the land."
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              </section>

              {/* Services Section */}
              <section id="services" className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="text-center mb-16">
                    <h2 className="text-4xl font-bold mb-4 organic-text">Our Specialties</h2>
                    <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                      From organic farming to wellness advocacy, we offer comprehensive services 
                      that nourish both body and community through sustainable practices.
                    </p>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-8">
                    {services.map((service, index) => (
                      <Card key={index} className="farm-card fade-in" style={{animationDelay: `${index * 0.1}s`}}>
                        <CardHeader>
                          <div className="flex items-center gap-3 mb-2">
                            {service.icon}
                            <CardTitle className="text-xl">{service.title}</CardTitle>
                          </div>
                          <CardDescription className="text-base">
                            {service.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          {service.image && (
                            <img 
                              src={service.image} 
                              alt={service.title}
                              className="w-full h-48 object-cover rounded-lg mb-4"
                            />
                          )}
                          <ul className="space-y-2">
                            {service.features.map((feature, featureIndex) => (
                              <li key={featureIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                                <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </section>

              {/* Farm Section */}
              <section id="farm" className="py-20 bg-muted/30">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="text-center mb-16">
                    <h2 className="text-4xl font-bold mb-4 organic-text">Our Farm & Biosecurity</h2>
                    <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                      To ensure the health and safety of our NPIP Certified Storm Troopers (Ayam Cemani chickens) 
                      and all our pasture-raised animals, we are unable to accommodate farm visits or tours at this time.
                      Our strict biosecurity measures, including designated paths for deliveries, are in place to maintain 
                      a clean flock and healthy environment for all our farm family.
                    </p>
                    <p className="text-lg text-muted-foreground mt-4">
                      We appreciate your understanding as we prioritize the well-being of our animals and the integrity of our organic practices.
                    </p>
                  </div>

                  {/* Farm Animals Gallery */}
                  <div className="mb-16">
                    <h3 className="text-3xl font-bold text-center mb-8 organic-text">Meet Our Farm Family</h3>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                      <Card className="farm-card">
                        <img 
                          src={allyCatImg} 
                          alt="AllyCat sleeping peacefully by the window"
                          className="w-full h-64 object-cover rounded-t-lg"
                        />
                        <CardHeader>
                          <CardTitle className="text-lg">AllyCat</CardTitle>
                          <CardDescription>
                            One of our three beloved farm cats, often found napping in cozy spots around the farm.
                          </CardDescription>
                        </CardHeader>
                      </Card>

                      <Card className="farm-card">
                        <img 
                          src={yardieTabbyImg} 
                          alt="Yardie, the beautiful tabby cat"
                          className="w-full h-64 object-cover rounded-t-lg"
                        />
                        <CardHeader>
                          <CardTitle className="text-lg">YardCat (Yardie)</CardTitle>
                          <CardDescription>
                            Our stunning tabby cat who loves exploring the farm grounds and keeping watch over our operations.
                          </CardDescription>
                        </CardHeader>
                      </Card>

                      <Card className="farm-card">
                        <img 
                          src={bobYardieImg} 
                          alt="Bob and Yardie cats together"
                          className="w-full h-64 object-cover rounded-t-lg"
                        />
                        <CardHeader>
                          <CardTitle className="text-lg">BobCat & YardCat</CardTitle>
                          <CardDescription>
                            Bob (mostly white) and Yardie (tabby) enjoying time together on the farm deck.
                          </CardDescription>
                        </CardHeader>
                      </Card>

                      <Card className="farm-card">
                        <img 
                          src={lyannaMormontImg} 
                          alt="Lyanna Mormont, the black lab terrier mix"
                          className="w-full h-64 object-cover rounded-t-lg"
                        />
                        <CardHeader>
                          <CardTitle className="text-lg">Lyanna Mormont</CardTitle>
                          <CardDescription>
                            Our fierce and loyal black lab terrier mix, named after the brave Game of Thrones character.
                          </CardDescription>
                        </CardHeader>
                      </Card>

                      <Card className="farm-card">
                        <img 
                          src={brandonStarkImg} 
                          alt="Brandon Stark, the European Doberman Pinscher"
                          className="w-full h-64 object-cover rounded-t-lg"
                        />
                        <CardHeader>
                          <CardTitle className="text-lg">Brandon Stark</CardTitle>
                          <CardDescription>
                            Our majestic European Doberman Pinscher, embodying strength and nobility like his Game of Thrones namesake.
                          </CardDescription>
                        </CardHeader>
                      </Card>

                      <Card className="farm-card bg-gradient-to-br from-primary/10 to-secondary/10">
                        <CardHeader className="text-center">
                          <Star className="w-12 h-12 star-wars-accent mx-auto mb-4" />
                          <CardTitle className="text-lg">Leia & Han Solo</CardTitle>
                          <CardDescription>
                            Our beloved miniature donkeys - Leia (black) and Han Solo (white) - the true stars of our Star Wars-themed farm!
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="text-center">
                          <p className="text-sm text-muted-foreground">
                            Schedule a visit to meet these charming ambassadors in person.
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              </section>

              {/* Contact Section */}
              <section id="contact" className="py-20 bg-muted/30">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="text-center mb-16">
                    <h2 className="text-4xl font-bold mb-4 organic-text">Get In Touch</h2>
                    <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                      Ready to start your journey toward sustainable living and wellness? Contact us to schedule a farm visit, consultation, or workshop.
                    </p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-12">
                    <div>
                      <h3 className="text-2xl font-bold mb-4 organic-text">Contact Information</h3>
                      <ul className="space-y-4 text-muted-foreground text-lg">
                        <li className="flex items-center gap-3">
                          <MapPin className="w-6 h-6 text-primary" />
                          LaGrange, Georgia
                        </li>
                        <li className="flex items-center gap-3">
                          <Phone className="w-6 h-6 text-primary" />
                          Available upon request
                        </li>
                        <li className="flex items-center gap-3">
                          <Mail className="w-6 h-6 text-primary" />
                          Contact through social media
                        </li>
                      </ul>

                      <h3 className="text-2xl font-bold mt-8 mb-4 organic-text">Business Hours</h3>
                      <ul className="space-y-2 text-muted-foreground text-lg">
                        <li>Educational workshops scheduled seasonally</li>
                        <li>Cottage food orders accepted year-round</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </section>

              {/* Footer */}
              <footer className="bg-primary py-12 text-primary-foreground">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <Leaf className="w-8 h-8" />
                      <span className="text-2xl font-bold">Nevaeh Seniah</span>
                    </div>
                    <p className="text-primary-foreground/80 mb-4">
                      Organic Farmer | Certified Beekeeper | Cottage Food Baker | Health & Wellness Advocate | Small Business Owner
                    </p>
                    <p className="text-primary-foreground/80 mb-4">
                      "From seed to plate" - Transparency, sustainability, and nourishing both body and community
                    </p>
                    <div className="flex justify-center space-x-6 mb-8">
                      <a href="https://www.facebook.com/NevaehSeniahLLC" target="_blank" rel="noopener noreferrer" className="text-primary-foreground hover:text-white transition-colors">
                        <Facebook className="w-7 h-7" />
                      </a>
                      <a href="https://www.instagram.com/nevaehseniah" target="_blank" rel="noopener noreferrer" className="text-primary-foreground hover:text-white transition-colors">
                        <Instagram className="w-7 h-7" />
                      </a>
                      <a href="https://twitter.com/NevaehSeniah" target="_blank" rel="noopener noreferrer" className="text-primary-foreground hover:text-white transition-colors">
                        <Twitter className="w-7 h-7" />
                      </a>
                      <a href="https://www.tiktok.com/@nevaehseniah" target="_blank" rel="noopener noreferrer" className="text-primary-foreground hover:text-white transition-colors">
                        <img src="/assets/tiktok-icon.png" alt="TikTok" className="w-7 h-7" />
                      </a>
                      <a href="https://www.youtube.com/@nevaehseniahllc" target="_blank" rel="noopener noreferrer" className="text-primary-foreground hover:text-white transition-colors">
                        <Youtube className="w-7 h-7" />
                      </a>
                    </div>
                    <div className="mt-8 pt-8 border-t border-primary-foreground/20">
                      <p className="text-primary-foreground/60 text-sm">
                        © 2025 Nevaeh Seniah. All rights reserved. | LaGrange, Georgia
                      </p>
                    </div>
                  </div>
                </div>
              </footer>
            </>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;


