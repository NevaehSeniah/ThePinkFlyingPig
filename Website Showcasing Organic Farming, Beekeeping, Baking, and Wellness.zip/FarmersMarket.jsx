import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { CalendarDays, MapPin } from 'lucide-react';

function FarmersMarket() {
  const upcomingEvents = [
    {
      date: 'August 2, 2025',
      time: '8:00 AM - 1:00 PM',
      location: 'The Market at the Rail',
      address: '206 E. Depot St. LaGrange, GA'
    },
    {
      date: 'August 9, 2025',
      time: '8:00 AM - 1:00 PM',
      location: 'The Market at the Rail',
      address: '206 E. Depot St. LaGrange, GA'
    },
    {
      date: 'August 16, 2025',
      time: '8:00 AM - 1:00 PM',
      location: 'The Market at the Rail',
      address: '206 E. Depot St. LaGrange, GA'
    },
    {
      date: 'August 23, 2025',
      time: '8:00 AM - 1:00 PM',
      location: 'The Market at the Rail',
      address: '206 E. Depot St. LaGrange, GA'
    }
  ];

  return (
    <div className="min-h-screen bg-muted/30 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 organic-text">Upcoming Farmer's Markets</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Come visit us at these local farmer's markets to get your fresh produce, delicious baked goods, and learn more about Nevaeh Seniah!
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {upcomingEvents.map((event, index) => (
            <Card key={index} className="farm-card fade-in" style={{animationDelay: `${index * 0.1}s`}}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalendarDays className="w-6 h-6 organic-text" />
                  {event.date}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-muted-foreground mb-2">{event.time}</p>
                <p className="text-lg font-semibold text-primary mb-1">{event.location}</p>
                <p className="text-muted-foreground flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {event.address}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center text-muted-foreground text-lg mt-16">
          <p>
            Follow us on social media for real-time updates on our market schedule and product availability!
          </p>
        </div>
      </div>
    </div>
  );
}

export default FarmersMarket;


