import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { ShieldCheck, FlaskConical, Truck, CheckCircle } from 'lucide-react';

function NPIPBiosecurity() {
  return (
    <div className="min-h-screen bg-muted/30 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-4 organic-text">NPIP Certification & Biosecurity</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            At Nevaeh Seniah, the health and well-being of our flock and all farm animals are our top priority. 
            We adhere to stringent biosecurity protocols and are proud to be NPIP Certified.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start mb-16">
          <div>
            <h2 className="text-3xl font-bold mb-6 organic-text flex items-center gap-3">
              <ShieldCheck className="w-8 h-8" />
              What is NPIP Certification?
            </h2>
            <p className="text-lg text-muted-foreground mb-4">
              At Nevaeh Seniah, LLC, we are proud to be NPIP Certified (Participant # [Your NPIP Number Here]) 
              through the National Poultry Improvement Plan. This certification ensures that our breeding flocks 
              are tested regularly and verified to be free of major poultry diseases like Pullorum-Typhoid and Avian Influenza.
            </p>
            <p className="text-lg text-muted-foreground">
              For more information about the NPIP program, visit: <a href="https://www.poultryimprovement.org" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">www.poultryimprovement.org</a>
            </p>
          </div>
          <div>
            <Card className="farm-card h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FlaskConical className="w-6 h-6 organic-text" />
                  Why does this matter to you?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-muted-foreground">
                  <li><CheckCircle className="inline-block w-4 h-4 mr-2 text-primary" />Healthy Flocks: Our birds are monitored under strict biosecurity and testing guidelines.</li>
                  <li><CheckCircle className="inline-block w-4 h-4 mr-2 text-primary" />Ship With Confidence: NPIP certification is required for shipping live birds and hatching eggs across state lines.</li>
                  <li><CheckCircle className="inline-block w-4 h-4 mr-2 text-primary" />Peace of Mind: You can trust that our Ayam Cemani and Rooster Roulettes are bred in a safe, disease-free environment.</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-8 honey-text text-center flex items-center justify-center gap-3">
            <Truck className="w-8 h-8" />
            Our Strict Biosecurity Practices
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="farm-card">
              <CardHeader>
                <CardTitle className="text-xl">Restricted Access</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To protect our NPIP Certified flock, general farm visits and tours are not permitted. 
                  This minimizes external contamination risks.
                </p>
              </CardContent>
            </Card>

            <Card className="farm-card">
              <CardHeader>
                <CardTitle className="text-xl">Designated Paths</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  All essential personnel, including delivery drivers, must adhere to strict, designated paths. 
                  No veering off to pet animals or explore other areas.
                </p>
              </CardContent>
            </Card>

            <Card className="farm-card">
              <CardHeader>
                <CardTitle className="text-xl">Equipment Sanitation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  All equipment entering and leaving the farm is thoroughly cleaned and disinfected to prevent 
                  the introduction or spread of pathogens.
                </p>
              </CardContent>
            </Card>

            <Card className="farm-card">
              <CardHeader>
                <CardTitle className="text-xl">Animal Health Monitoring</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Our animals are regularly monitored for any signs of illness, and prompt action is taken 
                  to isolate and treat any concerns, ensuring the health of the entire farm.
                </p>
              </CardContent>
            </Card>

            <Card className="farm-card">
              <CardHeader>
                <CardTitle className="text-xl">Feed & Water Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We use high-quality Kalmbach organic feed and ensure clean, fresh water sources to support 
                  the robust health and immune systems of our pasture-raised animals.
                </p>
              </CardContent>
            </Card>

            <Card className="farm-card">
              <CardHeader>
                <CardTitle className="text-xl">Pest Control</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Effective pest control measures are in place to prevent wild birds, rodents, and insects 
                  from introducing diseases to our flock.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center text-muted-foreground text-lg">
          <p>
            We believe in transparency and uphold the highest standards in poultry care—because healthy birds mean happy customers.
          </p>
        </div>
      </div>
    </div>
  );
}

export default NPIPBiosecurity;


