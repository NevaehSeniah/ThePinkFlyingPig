- [x] Research and gather visual assets (including user-provided photos and Star Wars theme)
- [x] Plan website structure and content strategy
- [x] Create website design and layout
- [x] Develop responsive website with content
- [x] Test website functionality and responsiveness
- [x] Deploy website and deliver to user
- [x] Update website content to reflect biosecurity and no visits

